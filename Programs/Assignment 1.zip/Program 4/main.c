
//================================================
// Description: Write a program which is used to display “Hello World” on screen and create its executable file.
// Input: void
// Output: Print Hello World!
// Author: Ganesh Narayan Jaiwal
// Date: 10 Sept 2020
//================================================

#include <stdio.h>

int main(int args, char *argv[])
{
    printf("Hello World.");
    return 0;
}
